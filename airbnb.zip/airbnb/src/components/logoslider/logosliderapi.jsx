export const logoapi = [

    {
        id: 1,
        img : 'https://a0.muscache.com/pictures/bcd1adc0-5cee-4d7a-85ec-f6730b0f8d0c.jpg',
        name : 'Beachfront'

    },
    {
        id: 2,
        img : 'https://a0.muscache.com/pictures/7630c83f-96a8-4232-9a10-0398661e2e6f.jpg',
        name : 'Rooms'

    },
    {
        id: 3,
        img : 'https://a0.muscache.com/pictures/677a041d-7264-4c45-bb72-52bff21eb6e8.jpg',
        name : 'Lakefront'

    },
    {
        id: 4,
        img : 'https://a0.muscache.com/pictures/732edad8-3ae0-49a8-a451-29a8010dcc0c.jpg',
        name : 'Cabins'

    },
    {
        id: 5,
        img : 'https://a0.muscache.com/pictures/c0fa9598-4e37-40f3-b734-4bd0e2377add.jpg',
        name : 'News'

    },
    {
        id: 6,
        img : 'https://a0.muscache.com/pictures/c0a24c04-ce1f-490c-833f-987613930eca.jpg',
        name : 'National parks'

    },
    {
        id: 7,
        img : 'https://a0.muscache.com/pictures/aaa02c2d-9f0d-4c41-878a-68c12ec6c6bd.jpg',
        name : 'Farms'

    },
    {
        id: 8,
        img : 'https://a0.muscache.com/pictures/3fb523a0-b622-4368-8142-b5e03df7549b.jpg',
        name : 'Amazing pools'

    },
    {
        id: 9,
        img : 'https://a0.muscache.com/pictures/3b1eb541-46d9-4bef-abc4-c37d77e3c21b.jpg',
        name : 'Amazing views'

    },
    {
        id: 10,
        img : 'https://a0.muscache.com/pictures/ee9e2a40-ffac-4db9-9080-b351efc3cfc4.jpg',
        name : 'Tropical'

    },
    {
        id: 11,
        img : 'https://a0.muscache.com/pictures/c5a4f6fc-c92c-4ae8-87dd-57f1ff1b89a6.jpg',
        name : 'OMG!'

    },
    {
        id: 12,
        img : 'https://a0.muscache.com/pictures/4d4a4eba-c7e4-43eb-9ce2-95e1d200d10e.jpg',
        name : 'Treehouses'

    },
    {
        id: 13,
        img : 'https://a0.muscache.com/pictures/ca25c7f3-0d1f-432b-9efa-b9f5dc6d8770.jpg',
        name : 'Camping'

    },
    {
        id: 14,
        img : 'https://a0.muscache.com/pictures/50861fca-582c-4bcc-89d3-857fb7ca6528.jpg',
        name : 'Design'

    },
    {
        id: 15,
        img : 'https://a0.muscache.com/pictures/6ad4bd95-f086-437d-97e3-14d12155ddfe.jpg',
        name : 'Countryside'

    },
    {
        id: 16,
        img : 'https://a0.muscache.com/pictures/6ad4bd95-f086-437d-97e3-14d12155ddfe.jpg',
        name : 'Countryside'

    },
    {
        id: 17,
        img : 'https://a0.muscache.com/pictures/6ad4bd95-f086-437d-97e3-14d12155ddfe.jpg',
        name : 'Countryside'

    },
    {
        id: 18,
        img : 'https://a0.muscache.com/pictures/6ad4bd95-f086-437d-97e3-14d12155ddfe.jpg',
        name : 'Countryside'

    },
    {
        id: 19,
        img : 'https://a0.muscache.com/pictures/6ad4bd95-f086-437d-97e3-14d12155ddfe.jpg',
        name : 'Countryside'

    },
    {
        id: 20,
        img : 'https://a0.muscache.com/pictures/6ad4bd95-f086-437d-97e3-14d12155ddfe.jpg',
        name : 'Countryside'

    },
    {
        id: 21,
        img : 'https://a0.muscache.com/pictures/ee9e2a40-ffac-4db9-9080-b351efc3cfc4.jpg',
        name : 'Tropical'

    },
    {
        id: 22,
        img : 'https://a0.muscache.com/pictures/c5a4f6fc-c92c-4ae8-87dd-57f1ff1b89a6.jpg',
        name : 'OMG!'

    },
    {
        id: 23,
        img : 'https://a0.muscache.com/pictures/4d4a4eba-c7e4-43eb-9ce2-95e1d200d10e.jpg',
        name : 'Treehouses'

    },
    {
        id: 24,
        img : 'https://a0.muscache.com/pictures/ca25c7f3-0d1f-432b-9efa-b9f5dc6d8770.jpg',
        name : 'Camping'

    },
    {
        id: 25,
        img : 'https://a0.muscache.com/pictures/50861fca-582c-4bcc-89d3-857fb7ca6528.jpg',
        name : 'Design'

    },
    {
        id: 26,
        img : 'https://a0.muscache.com/pictures/6ad4bd95-f086-437d-97e3-14d12155ddfe.jpg',
        name : 'Countryside'

    },
    {
        id: 27,
        img : 'https://a0.muscache.com/pictures/6ad4bd95-f086-437d-97e3-14d12155ddfe.jpg',
        name : 'Countryside'

    },
    {
        id: 28,
        img : 'https://a0.muscache.com/pictures/6ad4bd95-f086-437d-97e3-14d12155ddfe.jpg',
        name : 'Countryside'

    },
    {
        id: 29,
        img : 'https://a0.muscache.com/pictures/6ad4bd95-f086-437d-97e3-14d12155ddfe.jpg',
        name : 'Countryside'

    },
    {
        id: 30,
        img : 'https://a0.muscache.com/pictures/6ad4bd95-f086-437d-97e3-14d12155ddfe.jpg',
        name : 'Countryside'

    },
    {
        id: 31,
        img : 'https://a0.muscache.com/pictures/6ad4bd95-f086-437d-97e3-14d12155ddfe.jpg',
        name : 'Countryside'

    },

]